
<!DOCTYPE HTML>
<html>
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<head>
    <title></title>

</head>
<body>
<?php
//var_dump($gifts);
echo $gifts;
?>
<br>
<br>

请长按复制

<br>
<br>
<a href="indexx"><input type="button" value="返回"></a>
</body></html>