<div class="container-fluid" style=" background:#e7eaf1; position:fixed; bottom:0px; width:100%" >
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12" style="text-align:center; margin-top:5px;"><a href="indexx">首页&nbsp;</a>|&nbsp;57k游戏APP&nbsp;|&nbsp;分类&nbsp;|<a href="gifts">&nbsp;礼包</a></div>
    </div>
    <div class="row" style="margin-top:15px;">
        <div class="col-md-6 col-sm-6 col-xs-6" style="color:#999; text-align:center; margin-top:5px;">客服电话：18515635581</div>
        <div class="col-md-6 col-sm-6 col-xs-6" style="color:#999;text-align:center; margin-top:5px;">客服QQ:2453458109</div>
    </div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12" style="color:#999;text-align:center; margin-top:5px;">京ICP设备号11003178号 57k手游网版权所有</div>
    </div>

</div>
