<?php
//phpinfo();
$arr=array(1,2,2,3,4,9,5,5,6,6,7,7);
//var_dump($arr);

?>
<?php
//echo $username;
foreach($username as $key => $res)
{
    var_dump($res);
    echo $res;
}
//var_dump($game_name);
?>
<div onclick="check_login()"></div>

<script type="javascript">
    function check_login()
    {

    }

</script>